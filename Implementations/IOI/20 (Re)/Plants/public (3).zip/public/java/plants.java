public class plants {
	void init(int k, int[] r) {
		return;
	}
	
	int compare_plants(int x, int y) {
		return 0;
	}
}
