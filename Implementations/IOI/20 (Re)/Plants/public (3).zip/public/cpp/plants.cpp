#include "plants.h"

void init(int k, std::vector<int> r) {
	return;
}

int compare_plants(int x, int y) {
	return 0;
}
