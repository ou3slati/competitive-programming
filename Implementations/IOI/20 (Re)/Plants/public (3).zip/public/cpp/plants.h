#include <vector>

void init(int k, std::vector<int> r);
int compare_plants(int x, int y);
